
#ifndef MYRESPONSE_H_
#define MYRESPONSE_H_


char *response_404;
char *response_403;
char *response_200;


#endif