#ifndef MYLOG_H_
#define MYLOG_H_

void srvlog();
int sendLog(const char *logmsg);

#endif