#ifndef MYPARSER_H_
#define MYPARSER_H_

#include "stdio.h"
#include "stdlib.h"

#include "myfiles.h"
#include "limits.h"
#include "myconfload.h"
#include "unistd.h"
#include "fcntl.h"

void parser();

#endif